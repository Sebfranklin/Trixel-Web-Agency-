import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Award, 
  Shield, 
  Users, 
  Clock, 
  CheckCircle, 
  Star,
  Heart,
  Target,
  Eye,
  Wrench,
  GraduationCap,
  Phone
} from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    { icon: Users, number: '5,000+', label: 'Happy Customers' },
    { icon: Award, number: '20+', label: 'Years Experience' },
    { icon: Star, number: '99%', label: 'Satisfaction Rate' },
    { icon: Shield, number: '24/7', label: 'Emergency Service' }
  ];

  const values = [
    {
      icon: Heart,
      title: 'Customer First',
      description: 'We put our customers at the center of everything we do, ensuring their comfort and satisfaction is our top priority.'
    },
    {
      icon: Shield,
      title: 'Quality & Safety',
      description: 'We maintain the highest standards of quality workmanship and safety practices in every project we undertake.'
    },
    {
      icon: CheckCircle,
      title: 'Reliability',
      description: 'You can count on us to be there when you need us most, with consistent, dependable service every time.'
    },
    {
      icon: GraduationCap,
      title: 'Expertise',
      description: 'Our team continuously trains on the latest HVAC technologies to provide you with the most advanced solutions.'
    }
  ];

  const certifications = [
    'NATE Certified Technicians',
    'EPA Certified',
    'State Licensed Contractors',
    'ACCA Member',
    'Better Business Bureau A+',
    'Energy Star Partner',
    'Manufacturer Authorized Dealer',
    'Insured & Bonded'
  ];

  const teamMembers = [
    {
      name: 'John Mitchell',
      position: 'Owner & Master Technician',
      experience: '25+ years',
      certifications: 'NATE, EPA, Master HVAC License',
      description: 'John founded AirCare Pro with a vision to provide honest, reliable HVAC services to the community.'
    },
    {
      name: 'Sarah Thompson',
      position: 'Lead Service Manager',
      experience: '15+ years',
      certifications: 'NATE, Customer Service Excellence',
      description: 'Sarah ensures every customer receives exceptional service and coordinates our technical teams.'
    },
    {
      name: 'Mike Rodriguez',
      position: 'Senior Installation Specialist',
      experience: '18+ years',
      certifications: 'NATE, EPA, Installation Specialist',
      description: 'Mike leads our installation team with expertise in residential and commercial HVAC systems.'
    }
  ];

  const milestones = [
    { year: '2004', event: 'AirCare Pro founded with a commitment to quality service' },
    { year: '2008', event: 'Expanded to commercial HVAC services' },
    { year: '2012', event: 'Achieved 1,000+ satisfied customers milestone' },
    { year: '2016', event: 'Added emergency 24/7 service availability' },
    { year: '2020', event: 'Reached 5,000+ happy customers served' },
    { year: '2024', event: 'Celebrating 20 years of professional service' }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              About AirCare Pro
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Your trusted HVAC partner for over 20 years. Professional, reliable, 
              and committed to your comfort.
            </p>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-full mb-4">
                    <Icon className="h-8 w-8" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h2 className="text-4xl font-bold text-gray-900">Our Story</h2>
              <div className="space-y-4 text-lg text-gray-600 leading-relaxed">
                <p>
                  Founded in 2004, AirCare Pro began with a simple mission: to provide honest, 
                  reliable HVAC services to our community. What started as a small family business 
                  has grown into one of the region's most trusted heating and cooling companies.
                </p>
                <p>
                  Over the past 20 years, we've built our reputation on quality workmanship, 
                  exceptional customer service, and fair pricing. Our team of certified technicians 
                  brings decades of combined experience to every job, ensuring your complete satisfaction.
                </p>
                <p>
                  Today, we're proud to serve over 5,000 satisfied customers across the region, 
                  maintaining the same commitment to excellence that has defined us from day one.
                </p>
              </div>
            </div>
            
            <div className="bg-gray-200 rounded-xl h-96 flex items-center justify-center">
              <div className="text-center text-gray-500">
                <Users className="h-24 w-24 mx-auto mb-4 text-blue-600" />
                <p className="text-lg font-semibold">Our Team at Work</p>
                <p className="text-sm">Professional HVAC Service</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Mission, Vision & Values
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-16">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Target className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide exceptional HVAC services that exceed customer expectations while 
                maintaining the highest standards of professionalism, quality, and integrity.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Eye className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                To be the most trusted and respected HVAC company in our region, known for 
                our expertise, reliability, and commitment to customer satisfaction.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <Heart className="h-8 w-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Our Values</h3>
              <p className="text-gray-600 leading-relaxed">
                Integrity, excellence, and customer focus guide everything we do. We believe 
                in honest communication, quality workmanship, and treating every customer like family.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div key={index} className="bg-white rounded-lg p-6 shadow-lg text-center">
                  <div className="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">{value.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Meet Our Expert Team
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our certified professionals bring decades of experience and expertise to every project
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {teamMembers.map((member, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 text-center">
                <div className="w-32 h-32 bg-gray-300 rounded-full mx-auto mb-6 flex items-center justify-center">
                  <Users className="h-16 w-16 text-gray-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
                <p className="text-blue-600 font-semibold mb-2">{member.position}</p>
                <div className="space-y-2 text-sm text-gray-600 mb-4">
                  <p><strong>Experience:</strong> {member.experience}</p>
                  <p><strong>Certifications:</strong> {member.certifications}</p>
                </div>
                <p className="text-gray-700 text-sm leading-relaxed">{member.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Certifications & Awards */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Certifications & Credentials
            </h2>
            <p className="text-lg text-gray-600">
              We maintain the highest industry standards and certifications
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {certifications.map((cert, index) => (
              <div key={index} className="bg-white rounded-lg p-4 shadow-md text-center hover:shadow-lg transition-shadow">
                <Shield className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <p className="text-sm font-medium text-gray-900">{cert}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Company Timeline */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Journey
            </h2>
            <p className="text-xl text-gray-600">
              Two decades of growth, innovation, and customer service excellence
            </p>
          </div>

          <div className="space-y-8">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-center space-x-6">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center font-bold">
                  {milestone.year}
                </div>
                <div className="flex-1 bg-gray-50 rounded-lg p-6">
                  <p className="text-gray-700 text-lg">{milestone.event}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Ready to Experience the AirCare Pro Difference?
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of satisfied customers who trust us with their heating and cooling needs.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contact"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-colors"
              >
                Get Your Free Quote
              </Link>
              <a
                href="tel:555-123-4567"
                className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg font-bold text-lg transition-colors inline-flex items-center justify-center space-x-2"
              >
                <Phone className="h-5 w-5" />
                <span>Call Us Today</span>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
