import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Phone, 
  Star, 
  CheckCircle, 
  Shield, 
  Clock, 
  Thermometer,
  Wind,
  Settings,
  AlertTriangle,
  Users,
  Award,
  ThumbsUp
} from 'lucide-react';

const Home: React.FC = () => {
  const services = [
    {
      icon: Thermometer,
      title: 'Heating Systems',
      description: 'Expert installation, repair, and maintenance of furnaces, heat pumps, and boilers.',
      features: ['Energy Efficient', 'Expert Installation', '24/7 Service']
    },
    {
      icon: Wind,
      title: 'Air Conditioning',
      description: 'Complete AC solutions from installation to emergency repairs for optimal comfort.',
      features: ['Fast Cooling', 'Energy Saving', 'Smart Controls']
    },
    {
      icon: Settings,
      title: 'Ventilation',
      description: 'Professional ductwork design and installation for improved air quality.',
      features: ['Clean Air', 'Proper Airflow', 'Quiet Operation']
    },
    {
      icon: AlertTriangle,
      title: 'Emergency Repair',
      description: '24/7 emergency HVAC services when you need us most.',
      features: ['24/7 Available', 'Fast Response', 'Licensed Techs']
    }
  ];

  const testimonials = [
    {
      name: 'Sarah Johnson',
      rating: 5,
      comment: 'Outstanding service! They fixed our AC unit quickly and professionally. Highly recommend!',
      location: 'Downtown District'
    },
    {
      name: 'Mike Chen',
      rating: 5,
      comment: 'AirCare Pro installed our new heating system. Quality work at a fair price.',
      location: 'Riverside Area'
    },
    {
      name: 'Lisa Rodriguez',
      rating: 5,
      comment: 'Emergency service on a Sunday - they came right out and got our heat working again.',
      location: 'Westside'
    }
  ];

  const stats = [
    { icon: Users, number: '5000+', label: 'Happy Customers' },
    { icon: Award, number: '20+', label: 'Years Experience' },
    { icon: ThumbsUp, number: '99%', label: 'Satisfaction Rate' },
    { icon: Shield, number: '24/7', label: 'Emergency Service' }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-900 via-blue-800 to-blue-600 text-white">
        <div className="absolute inset-0 bg-black opacity-40"></div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                  Professional
                  <span className="block text-blue-300">HVAC Solutions</span>
                </h1>
                <p className="text-xl lg:text-2xl text-blue-100 leading-relaxed">
                  Expert heating, cooling, and ventilation services for your home and business. 
                  Licensed, insured, and trusted by thousands of customers.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/contact"
                  className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg text-center"
                >
                  Get Free Quote
                </Link>
                <a
                  href="tel:555-123-4567"
                  className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-900 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all text-center"
                >
                  Call Now: (555) 123-4567
                </a>
              </div>

              <div className="flex items-center space-x-6 pt-4">
                <div className="flex items-center space-x-2">
                  <Shield className="h-6 w-6 text-green-400" />
                  <span className="text-sm">Licensed & Insured</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="h-6 w-6 text-green-400" />
                  <span className="text-sm">24/7 Emergency</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Star className="h-6 w-6 text-yellow-400" />
                  <span className="text-sm">5-Star Rated</span>
                </div>
              </div>
            </div>

            <div className="hidden lg:block">
              <div className="bg-white bg-opacity-10 backdrop-blur-sm rounded-2xl p-8 space-y-6">
                <h3 className="text-2xl font-bold text-center">Why Choose AirCare Pro?</h3>
                <div className="space-y-4">
                  {[
                    'Same-day service available',
                    'Upfront, honest pricing',
                    'Highly trained technicians',
                    'Satisfaction guaranteed',
                    'Energy-efficient solutions'
                  ].map((benefit, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <CheckCircle className="h-5 w-5 text-green-400" />
                      <span>{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 text-white rounded-full mb-4">
                    <Icon className="h-8 w-8" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Complete HVAC Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From installation to emergency repairs, we provide comprehensive HVAC solutions 
              to keep your home or business comfortable year-round.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div key={index} className="bg-white rounded-xl p-6 shadow-lg border border-gray-100 hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
                  <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center mb-6">
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-4 leading-relaxed">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center space-x-2 text-sm">
                        <CheckCircle className="h-4 w-4 text-green-500" />
                        <span className="text-gray-700">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>

          <div className="text-center mt-12">
            <Link
              to="/services"
              className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
            >
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* Emergency CTA Section */}
      <section className="bg-red-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              HVAC Emergency? We're Here to Help!
            </h2>
            <p className="text-xl mb-8 text-red-100">
              Don't suffer in extreme temperatures. Our emergency technicians are available 24/7 
              to restore your comfort quickly and safely.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:555-123-4567"
                className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-colors inline-flex items-center justify-center space-x-2"
              >
                <Phone className="h-5 w-5" />
                <span>Call Emergency Line</span>
              </a>
              <Link
                to="/contact"
                className="bg-transparent border-2 border-white hover:bg-white hover:text-red-600 px-8 py-4 rounded-lg font-bold text-lg transition-colors"
              >
                Schedule Service
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-xl text-gray-600">
              Don't just take our word for it - hear from satisfied customers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 italic">"{testimonial.comment}"</p>
                <div>
                  <p className="font-semibold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA Section */}
      <section className="bg-blue-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Ready for Better Comfort?
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Get a free estimate on your HVAC project today. Professional service, 
              competitive pricing, and satisfaction guaranteed.
            </p>
            <Link
              to="/contact"
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Get Your Free Quote Today
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
