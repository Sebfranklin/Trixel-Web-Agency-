import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Thermometer, 
  Wind, 
  Settings, 
  AlertTriangle, 
  Wrench, 
  CheckCircle,
  Phone,
  Star,
  DollarSign,
  Clock,
  Shield
} from 'lucide-react';

const Services: React.FC = () => {
  const mainServices = [
    {
      icon: Thermometer,
      title: 'Heating Systems',
      description: 'Complete heating solutions for your home and business',
      services: [
        'Furnace Installation & Repair',
        'Heat Pump Systems',
        'Boiler Service & Maintenance',
        'Radiant Floor Heating',
        'Ductless Mini-Split Systems',
        'Energy Efficiency Upgrades'
      ],
      features: [
        'Energy Efficient Models',
        'Professional Installation',
        'Same-Day Repairs',
        'Warranty Protection'
      ],
      image: '/images/heating-system.jpg'
    },
    {
      icon: Wind,
      title: 'Air Conditioning',
      description: 'Expert cooling solutions to keep you comfortable year-round',
      services: [
        'Central AC Installation',
        'AC Repair & Maintenance',
        'Ductless Mini-Split AC',
        'Commercial HVAC Systems',
        'Smart Thermostat Installation',
        'Energy Audit & Optimization'
      ],
      features: [
        'Fast Cooling Solutions',
        'Energy Star Certified',
        'Smart Home Integration',
        '24/7 Emergency Service'
      ],
      image: '/images/ac-installation.jpg'
    },
    {
      icon: Settings,
      title: 'Ventilation & Air Quality',
      description: 'Improve your indoor air quality with professional ventilation solutions',
      services: [
        'Ductwork Design & Installation',
        'Air Duct Cleaning',
        'Ventilation System Repair',
        'Indoor Air Quality Testing',
        'Air Filtration Systems',
        'Humidity Control Solutions'
      ],
      features: [
        'Clean, Fresh Air',
        'Proper Airflow Design',
        'Allergen Reduction',
        'Energy Efficient Systems'
      ],
      image: '/images/ventilation-system.jpg'
    },
    {
      icon: Wrench,
      title: 'Maintenance Plans',
      description: 'Preventive maintenance to keep your HVAC system running efficiently',
      services: [
        'Annual System Inspections',
        'Seasonal Tune-ups',
        'Filter Replacement Programs',
        'Performance Optimization',
        'Priority Service Scheduling',
        'Extended Warranty Options'
      ],
      features: [
        'Prevent Costly Repairs',
        'Extend System Life',
        'Priority Scheduling',
        'Discounted Rates'
      ],
      image: '/images/maintenance-service.jpg'
    },
    {
      icon: AlertTriangle,
      title: 'Emergency Repair',
      description: '24/7 emergency HVAC services when you need us most',
      services: [
        '24/7 Emergency Response',
        'System Diagnostics',
        'Same-Day Repairs',
        'Emergency Replacement',
        'Weekend & Holiday Service',
        'No-Heat/No-Cool Emergency'
      ],
      features: [
        'Available 24/7/365',
        'Fast Response Time',
        'Licensed Technicians',
        'Upfront Pricing'
      ],
      image: '/images/hero-technician.jpg'
    }
  ];

  const additionalServices = [
    'Commercial HVAC Systems',
    'Indoor Air Quality Solutions',
    'Smart Home Integration',
    'Energy Efficiency Consulting',
    'Duct Sealing & Repair',
    'Zoning System Installation',
    'Heat Recovery Ventilation',
    'Geothermal Systems'
  ];

  const whyChooseUs = [
    {
      icon: Shield,
      title: 'Licensed & Insured',
      description: 'Fully licensed technicians with comprehensive insurance coverage'
    },
    {
      icon: Star,
      title: '5-Star Service',
      description: 'Consistently rated 5 stars by satisfied customers'
    },
    {
      icon: DollarSign,
      title: 'Upfront Pricing',
      description: 'No hidden fees - you know the cost before we start'
    },
    {
      icon: Clock,
      title: 'Fast Response',
      description: 'Same-day service available for urgent repairs'
    }
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-bold mb-6">
              Professional HVAC Services
            </h1>
            <p className="text-xl lg:text-2xl text-blue-100 mb-8 max-w-3xl mx-auto">
              Complete heating, cooling, and ventilation solutions for residential and commercial properties. 
              Expert service you can trust.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link
                to="/contact"
                className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Get Free Quote
              </Link>
              <a
                href="tel:555-123-4567"
                className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-900 px-8 py-3 rounded-lg font-semibold transition-colors"
              >
                Call: (555) 123-4567
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Main Services */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">
              Our Complete HVAC Services
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From installation to maintenance, we provide comprehensive HVAC solutions 
              to meet all your heating and cooling needs.
            </p>
          </div>

          <div className="space-y-16">
            {mainServices.map((service, index) => {
              const Icon = service.icon;
              const isEven = index % 2 === 0;
              
              return (
                <div key={index} className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center ${!isEven ? 'lg:flex-row-reverse' : ''}`}>
                  <div className={`space-y-6 ${!isEven ? 'lg:order-2' : ''}`}>
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-blue-600 rounded-lg flex items-center justify-center">
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-3xl font-bold text-gray-900">{service.title}</h3>
                    </div>
                    
                    <p className="text-lg text-gray-600 leading-relaxed">
                      {service.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Services Include:</h4>
                        <ul className="space-y-2">
                          {service.services.map((item, itemIndex) => (
                            <li key={itemIndex} className="flex items-start space-x-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-700">{item}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
                        <ul className="space-y-2">
                          {service.features.map((feature, featureIndex) => (
                            <li key={featureIndex} className="flex items-start space-x-2 text-sm">
                              <Star className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                              <span className="text-gray-700">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    <div className="pt-4">
                      <Link
                        to="/contact"
                        className="inline-block bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
                      >
                        Request Service
                      </Link>
                    </div>
                  </div>

                  <div className={`${!isEven ? 'lg:order-1' : ''}`}>
                    <div className="bg-gray-200 rounded-xl h-80 flex items-center justify-center">
                      <div className="text-center text-gray-500">
                        <Icon className="h-24 w-24 mx-auto mb-4 text-blue-600" />
                        <p className="text-lg font-semibold">{service.title}</p>
                        <p className="text-sm">Professional Service Image</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Additional Services */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Additional Specialized Services
            </h2>
            <p className="text-lg text-gray-600">
              We also provide specialized HVAC solutions for unique requirements
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {additionalServices.map((service, index) => (
              <div key={index} className="bg-white rounded-lg p-4 shadow-md text-center hover:shadow-lg transition-shadow">
                <CheckCircle className="h-6 w-6 text-green-500 mx-auto mb-2" />
                <p className="text-sm font-medium text-gray-900">{service}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose AirCare Pro?
            </h2>
            <p className="text-lg text-gray-600">
              Experience the difference with our professional HVAC services
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {whyChooseUs.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index} className="text-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-600 text-sm">{item.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Emergency CTA */}
      <section className="bg-red-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Need Emergency HVAC Service?
            </h2>
            <p className="text-xl mb-8 text-red-100">
              Don't wait! Our emergency technicians are standing by 24/7 to restore your comfort.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="tel:555-123-4567"
                className="bg-white text-red-600 hover:bg-gray-100 px-8 py-4 rounded-lg font-bold text-lg transition-colors inline-flex items-center justify-center space-x-2"
              >
                <Phone className="h-5 w-5" />
                <span>Call Emergency Line</span>
              </a>
              <Link
                to="/contact"
                className="bg-transparent border-2 border-white hover:bg-white hover:text-red-600 px-8 py-4 rounded-lg font-bold text-lg transition-colors"
              >
                Schedule Service
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="bg-blue-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Ready to Get Started?
            </h2>
            <p className="text-xl mb-8 text-blue-100">
              Contact us today for a free consultation and estimate on your HVAC project.
            </p>
            <Link
              to="/contact"
              className="bg-red-600 hover:bg-red-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg"
            >
              Get Your Free Quote
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
